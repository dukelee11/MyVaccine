import React, { useState } from 'react';
import { Redirect } from 'react-router-dom';
import { Button, Container, Row, Col, Table } from 'react-bootstrap';

import classes from './NewInfo.module.scss';

export default function NewInfo(props) {


}