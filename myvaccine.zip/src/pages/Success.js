import React from 'react';
import { Button, Container, Row, Col, Table } from 'react-bootstrap';

export default function Success() {
  return (
    <div>
      <Container>
        <h1>SUCCESSFUL!</h1>
      </Container>
    </div>
  );
}
