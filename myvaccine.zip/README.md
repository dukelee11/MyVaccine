# MyVaccine
Schedule and manage COVID vaccination appointments.
<p align='center'><img src="./src/assets/home-page-screenshot.png" height="300"/></p>
